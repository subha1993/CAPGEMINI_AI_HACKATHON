
# coding: utf-8

# In[15]:


import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt
from datetime import datetime
import statsmodels.api as sm
from IPython.display import Image
from matplotlib.pylab import rcParams
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.stattools import acf, pacf
from sklearn.linear_model import LinearRegression
from statsmodels.tsa.arima_model import ARMA, ARIMA
from sklearn.metrics import explained_variance_score

#read the dataset into pandas dataframe
cols = ['name','avl','timestamp']
df = pd.read_csv('D:\\AI_HAckathon\\KLCC_parking\\parking-2-klcc-2016-2017.csv',na_values ='OPEN',header=None,names=cols,parse_dates=['timestamp'])
df = df.set_index('timestamp')

# filling in NaN by interpolating
df.interpolate(inplace=True,method='time')

# groups the data in buckets by Hour and taking mean
df = df['avl'].resample('H').mean()

#creating train and test dataset
train=df[0:1150]
test_data=df[1150:1250]
print(train)

#plot train dataset
plt.figure(figsize=(12,8))
plt.plot(train.index, train, label='Train')
plt.title("Hourly Availability of Train dataset")
plt.gcf().autofmt_xdate()
plt.show()

#method to perform dickey-fuller test for stationary timeseries
def evaluate_stationarity(timeseries, t):
    #Determing rolling statistics
    rolmean = timeseries.rolling(window=t).mean()
    rolstd = timeseries.rolling(window=t).std()
    #Plot rolling statistics:
    orig = plt.plot(timeseries, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.title('Rolling Mean & Standard Deviation')
    plt.gcf().autofmt_xdate()
    plt.show(block=False)
    #Perform Dickey-Fuller test:
    print ('Results of Dickey-Fuller Test:')
    dftest = adfuller(timeseries, autolag='AIC')
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic',
    'p-value','#Lags Used','Number of Observations Used'])
    for key,value in dftest[4].items():
        dfoutput['Critical Value (%s)'%key] = value
    print (dfoutput)
    return
    
#checking the stationarity of the train dataset
evaluate_stationarity(train, 24)
  
#log transform the Train data, to make the series stationary
train_log = np.log(train)

#checking the stationarity of the log-transformed train dataset
evaluate_stationarity(train_log, 24)
    
    
#eliminating Trend and Seasonality by first order differenting
#result of adfuller test shows improvement. Hence d should be 1 in ARIMA model params
data_diff = train_log - train_log.shift()
data_diff.dropna(inplace=True)
print("differentiated train data -")
print(data_diff)
evaluate_stationarity(data_diff,24)


#ACF and PACF plots:
from statsmodels.tsa.stattools import acf, pacf
lag_acf = acf(train_log, nlags=10)
lag_pacf = pacf(train_log, nlags=10, method='ols')

#Plot ACF: showing that the p value should be 6 or 7
plt.subplot(121) 
plt.plot(lag_acf)
plt.axhline(y=0,linestyle='--',color='gray')
plt.axhline(y=-1.96/np.sqrt(len(train_log)),linestyle='--',color='gray')
plt.axhline(y=1.96/np.sqrt(len(train_log)),linestyle='--',color='gray')
plt.title('Autocorrelation Function')

#Plot PACF: showing the q value should be 1 or 2
plt.subplot(122)
plt.plot(lag_pacf)
plt.axhline(y=0,linestyle='--',color='gray')
plt.axhline(y=-1.96/np.sqrt(len(train_log)),linestyle='--',color='gray')
plt.axhline(y=1.96/np.sqrt(len(train_log)),linestyle='--',color='gray')
plt.title('Partial Autocorrelation Function')
plt.tight_layout()
plt.show()

#fit ARIMA model on log transformed train data, p = 6 , d = 1, q = 1
from statsmodels.tsa.arima_model import ARIMA
model = ARIMA(train_log, order=(6,1,1))  
results_ARIMA = model.fit(disp=0)  
print("ARIMA aic -")
print(results_ARIMA.aic)

print("ARIMA fitted values -")
print(results_ARIMA.fittedvalues)

# This returns an array of future predictions for the same number of timesteps as in the Test data
future_forecast_ar = results_ARIMA.forecast(steps=test_data.size)
future_forecast = pd.Series(future_forecast_ar[0],copy=True,index = test_data.index)
print("future forecast in log scale -")
print(future_forecast)

#back to original scale
future_forecast_org = np.exp(future_forecast)
print("forecasted values in original scale -")
print(future_forecast_org)

plt.title('Test vs Forecasted data, RMSE: %.4f'% np.sqrt(sum((future_forecast_org-test_data)**2)/len(test_data)))
plt.plot(test_data,label='Test Data')
plt.plot(future_forecast_org, label='Predicted Data')
plt.legend(loc='best')
plt.gcf().autofmt_xdate()
plt.show()


# In[16]:


#rolling over prediction
train_1 = train.values
test_1 = test_data.values

history = [x for x in train_1]
predictions = list()
for t in range(len(test_1)):
    model = ARIMA(history, order=(1,1,1))
    model_fit = model.fit(disp=0)
    output = model_fit.forecast()
    print(model_fit.aic)
    yhat = output[0]
    predictions.append(yhat)
    obs = test_1[t]
    history.append(obs)
    print('predicted=%f, expected=%f' % (yhat, obs))

predictions_se = pd.Series(predictions, copy=True)    
print("predictions_series-")
print(predictions_se)
plt.title('RMSE: %.4f'% np.sqrt(sum((predictions_se-test_1)**2)/len(test_1)))


plt.title('Test vs Forecasted data, RMSE: %.4f'% np.sqrt(sum((predictions_se-test_1)**2)/len(test_1)))
plt.plot(test_1,label='Test Data')
plt.plot(predictions_se, label='Predicted Data')
plt.legend(loc='best')
plt.gcf().autofmt_xdate()
plt.show()

