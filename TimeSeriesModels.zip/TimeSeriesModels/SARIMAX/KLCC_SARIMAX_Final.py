
# coding: utf-8

# In[5]:


import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt
from datetime import datetime
import statsmodels.api as sm
from IPython.display import Image
from matplotlib.pylab import rcParams
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.stattools import acf, pacf
from sklearn.linear_model import LinearRegression
from statsmodels.tsa.arima_model import ARMA, ARIMA
from sklearn.metrics import explained_variance_score

import warnings
import itertools
warnings.filterwarnings("ignore") # specify to ignore warning messages

#read the dataset into pandas dataframe
cols = ['name','avl','timestamp']
df = pd.read_csv('D:\\AI_HAckathon\\KLCC_parking\\parking-2-klcc-2016-2017.csv',na_values ='OPEN',header=None,names=cols,parse_dates=['timestamp'])
df = df.set_index('timestamp')

print(df)
# filling in NaN by interpolating
df.interpolate(inplace=True,method='time')

# groups the data in buckets by Hour and taking mean
df = df['avl'].resample('H').mean()

#creating train and test dataset
train=df[0:1150]
test=df[1150:1250]

#plot train dataset
plt.figure(figsize=(12,8))
plt.plot(train.index, train, label='Train')
plt.title("Hourly Availability of Train dataset")
plt.gcf().autofmt_xdate()
plt.show()

#method to perform dickey-fuller test for stationary timeseries
def evaluate_stationarity(timeseries, t):
    #Determing rolling statistics
    rolmean = timeseries.rolling(window=t).mean()
    rolstd = timeseries.rolling(window=t).std()
    #Plot rolling statistics:
    orig = plt.plot(timeseries, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.title('Rolling Mean & Standard Deviation')
    plt.gcf().autofmt_xdate()
    plt.show(block=False)
    #Perform Dickey-Fuller test:
    print ('Results of Dickey-Fuller Test:')
    dftest = adfuller(timeseries, autolag='AIC')
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic',
    'p-value','#Lags Used','Number of Observations Used'])
    for key,value in dftest[4].items():
        dfoutput['Critical Value (%s)'%key] = value
    print (dfoutput)
    return
    
#checking the stationarity of the train dataset
evaluate_stationarity(train, 24)


#log transform the Train data, to make the series stationary
train_log = np.log(train)

#checking the stationarity of the log-transformed train dataset
evaluate_stationarity(train_log, 24)


#eliminating Trend and Seasonality by first order differenting
data_diff = train_log - train_log.shift()
data_diff.dropna(inplace=True)
print("differentiated and log transformed train data -")
print(data_diff)
evaluate_stationarity(data_diff,24)

#grid search for params of SARIMAX
p = d = q = range(0, 2) # Define the p, d and q parameters to take any value between 0 and 2
pdq = list(itertools.product(p, d, q)) # Generate all different combinations of p, q and q triplets
pdq_x_QDQs = [(x[0], x[1], x[2], 24) for x in list(itertools.product(p, d, q))] # Generate all different combinations of seasonal p, q and q triplets
print('Examples of Seasonal ARIMA parameter combinations for Seasonal ARIMA...')
print('SARIMAX: {} x {}'.format(pdq[1], pdq_x_QDQs[1]))
print('SARIMAX: {} x {}'.format(pdq[2], pdq_x_QDQs[2]))

for param in pdq:
    for seasonal_param in pdq_x_QDQs:
        try:
            mod = sm.tsa.statespace.SARIMAX(train_log,order=param,seasonal_order=seasonal_param,enforce_stationarity=False,enforce_invertibility=False)
            results_sarimax = mod.fit()
            print('SARIMAX{}x{} - AIC:{}'.format(param, seasonal_param, results_sarimax.aic))
        except:
            continue
            
            


# In[6]:


#train the model with params as found with lowest aic
mod = sm.tsa.statespace.SARIMAX(train_log, 
                                order=(1,0,1), 
                                seasonal_order=(1,1,1,24),   
                                enforce_stationarity=False,
                                enforce_invertibility=False)
results_SARIMAX = mod.fit(disp=0)
print(results_SARIMAX.summary())
print(results_SARIMAX.aic)

# Forecasting future hour's value, for the same number of timesteps as the size of the test dataset
future_forecast_ar = results_SARIMAX.forecast(steps=test.size)
future_forecast = pd.Series(future_forecast_ar,copy=True,index = test.index)

print("future forecast in series log scale -")
print(future_forecast)
future_forecast_scale = np.exp(future_forecast)
print("future forecast original scale -")
print(future_forecast_scale)

plt.title('Test vs Forecasted data, RMSE: %.4f'% np.sqrt(sum((future_forecast_scale-test)**2)/len(test)))
plt.plot(test,label='Test Data')
plt.plot(future_forecast_scale, label='Predicted Data')
plt.legend(loc='best')
plt.gcf().autofmt_xdate()
plt.show()


# In[7]:


#rolling over prediction, fitting the model on data in original scale
#the model makes a forecast of only 1 hour in future, then the model is retrained with taking the next hour's actual
#value into consideration.

train_1 = train.values
test_1 = test.values

history = [x for x in train_1]
predictions = list()
for t in range(len(test_1)):
    model = sm.tsa.statespace.SARIMAX(history, 
                                order=(1,0,1), 
                                seasonal_order=(1,1,1,24),   
                                enforce_stationarity=False,
                                enforce_invertibility=False)
    model_fit = model.fit(disp=0)
    output = model_fit.forecast()
    print(model_fit.aic)
    yhat = output[0]
    predictions.append(yhat)
    obs = test_1[t]
    history.append(obs)
    print('predicted=%f, expected=%f' % (yhat, obs))

predictions_se = pd.Series(predictions, copy=True)    
print("predictions_series-")
print(predictions_se)
plt.title('RMSE: %.4f'% np.sqrt(sum((predictions_se-test_1)**2)/len(test_1)))
plt.plot(test_1,label='Test Data')
plt.plot(predictions_se, label='Predicted Data')
plt.legend(loc='best')
plt.gcf().autofmt_xdate()
plt.show()

