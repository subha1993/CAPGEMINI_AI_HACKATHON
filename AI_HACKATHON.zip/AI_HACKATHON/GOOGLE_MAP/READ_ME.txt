Step1 : Rename the Location_Trace.html file from .html to .txt.
Step 2: Open Location_Trace.txt file then.
Step 3: Paste your API Key there.
Step 4: Rename the Location_Trace.txt back to Location_Trace.html
Step 5: Run the html file.